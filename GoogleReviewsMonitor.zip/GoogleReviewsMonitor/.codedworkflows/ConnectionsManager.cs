using UiPath.CodedWorkflows;
using System;

namespace GoogleReviewsMonitor
{
    public class ConnectionsManager
    {
        public ConnectionsManager(ICodedWorkflowsServiceContainer resolver)
        {
        }
    }
}